#include "Config.h"
#include "Mesh.h"
#include "Hal_2533.h"
#include <msp430g2533.h>
#include "RF_CC1101_2533.h"

uint8 flagnum;		// used to handle UART received bytes
uint8 c;			// cache for received UART byte
uint8 serial_ID;	// target ID of UART command
uint8 serial_Type;	// target command type of UART command
int8 serial_rt;		// return value in UART command progress
uint8 serial_Route[MAX_ROUTE_LENGTH];	// route for UART command
uint8 serial_p[3];	// UART Tx buffer
uint8 serial_i;

const uint8 LOCAL_NODE_ID = 1;					// 1 - Master node
												// other address - Slave node

const uint8 APPLICATION_DATA_LENGTH = 4;		// application data length, this contains the figure which will be sent from RF
uint8 demo_data[4] = {0x11, 0x22, 0x33, 0x44};

// interval for periodical events
const uint8 JOIN_INTERVAL = 5;					// interval between each actively Join Request frame, unit is second
const uint8 DATA_INTERVAL = 10;					// interval to actively report data, unit is second
const uint8 DISCOVERY_INTERVAL = 60;			// interval to discovery for the first Slave node, unit is second
const uint8 TOPOLOGY_INTERVAL = 60;				// interval to print current topology
const uint8 RESPONSE_INTERVAL = 180;			// interval to allow all slave to response to discovery broadcast again

// time for waiting for response
const uint8 RESPONSE_TIME_PERIOD = 100;			// time to wait for response after sending a packet, unit is 10 ms
const uint8 SLAVE_BROADCAST_TIME_PERIOD = 50;	// time for slave to wait before send back discovery nonresponse

const uint8 MAX_DATA_REPORT_TIMES = 10;
const uint8 MAX_JOIN_REPORT_TIMES = 10;
const uint8 MAX_REQUEST_TIMES = 1;

////////////////////////////////////////////////////////////////////////////////////////////////////
// FUNCT:
//		main
// DESCR:
//		This is the main entry.
// INPUTS:
//		None.
// OUTPUTS:
//		None.
// RETURN:
//		None.
// Considerations:
//		None.
////////////////////////////////////////////////////////////////////////////////////////////////////
void main(void)
{
	Hal_Init();

	Hal_ClearWDT();

	RF_Reset();
	RF_Init();

	RF_Receive_On();
	rf_state.receiving = 1;

	Mesh_Init();

	P2IFG = 0;

	while(1)
	{
		_EINT();

		Hal_ClearWDT();

		if(rf_state.receiving != 1)
		{
			RF_Receive_On();
			rf_state.receiving = 1;
		}

		Mesh_Run();

#ifdef MASTER
		// UART command protocol
		// PC to MCU:	0xAA ID Type
		// MCU to PC:	0xCC ID Type	command is send by RF successfully
		//				0xFF ID Type	command is not send because of there is no available route
		if(hal_UART_Flag == TRUE)
		{
			Hal_DelayMs(10);
			flagnum = 0;
			while(Hal_UART_GetOneByte(&c) == TRUE)
			{
				switch(flagnum)
				{
					case 0:
						if(c == 0xAA)
						{
							flagnum ++;
						}
						break;

					case 1:
						flagnum ++;
						serial_ID = c;
						break;

					case 2:
						flagnum ++;
						serial_Type = c;
						serial_rt = Mesh_Find_Best_Path(MASTER_ADDRESS, serial_ID, serial_Route, link_quality);
						if(serial_rt == 0 || serial_rt == -1)
						{
							serial_p[0] = 0xFF;
							serial_p[1] = serial_ID;
							serial_p[2] = serial_Type;
							Hal_UART_Send(hal_UART_Head, 2);
							Hal_UART_Send(serial_p, 3);
							Hal_UART_Send(hal_UART_Tail, 2);
						}
						else
						{
							if(serial_Type == COMMAND_DATA_REQUEST)
							{
								attr.Master_Flag |= DATA_REQUEST_FLAG;
								attr.Data_Request_ID = serial_ID;
							}
							else if(serial_Type == COMMAND_DISCOVERY_REQUEST)
							{
								//attr.Data_Request_Flag = TRUE;
								//attr.Data_Request_ID = serial_ID;
							}
							serial_p[0] = 0xCC;
							serial_p[1] = serial_ID;
							serial_p[2] = serial_Type;
							Hal_UART_Send(hal_UART_Head, 2);
							Hal_UART_Send(serial_p, 3);
							Hal_UART_Send(hal_UART_Tail, 2);
						}
						break;

					default:
						flagnum = 0;
						break;
				}
			}
			hal_UART_Flag = FALSE;
		}
#endif
	}
}




